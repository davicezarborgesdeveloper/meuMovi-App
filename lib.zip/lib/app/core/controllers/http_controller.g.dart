// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'http_controller.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_brace_in_string_interps, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic, no_leading_underscores_for_local_identifiers

mixin _$HttpController on HttpControllerBase, Store {
  late final _$_customDioAtom =
      Atom(name: 'HttpControllerBase._customDio', context: context);

  CustomDio? get customDio {
    _$_customDioAtom.reportRead();
    return super._customDio;
  }

  @override
  CustomDio? get _customDio => customDio;

  @override
  set _customDio(CustomDio? value) {
    _$_customDioAtom.reportWrite(value, super._customDio, () {
      super._customDio = value;
    });
  }

  @override
  String toString() {
    return '''

    ''';
  }
}
