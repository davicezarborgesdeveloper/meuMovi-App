enum SharedStoreKeys {
  authAccess('authAccess'),
  keepLogged('keepLogged');

  final String key;

  const SharedStoreKeys(this.key);
}
