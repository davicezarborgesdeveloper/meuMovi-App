class UnauthorizedException implements Exception {}
