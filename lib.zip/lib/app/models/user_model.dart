abstract class UserModel {
  String toJson();
}
