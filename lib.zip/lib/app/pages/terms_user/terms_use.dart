import 'package:flutter/material.dart';

class TermsUse extends StatelessWidget {
  const TermsUse({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Termo de uso'),
      ),
      body: Container(),
    );
  }
}
