import 'package:flutter/material.dart';

class RememberMePage extends StatelessWidget {
  const RememberMePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Esqueceu sua senha?'),
      ),
      body: Container(),
    );
  }
}
